#include "Sage.h"

const std::string Sage::m_class_name = "Sage";
const std::string Sage::m_class_description = "Sage Description Here";
const Class_id Sage::m_class_id = sage_id;

Sage::Sage(const int &level)
	: CharacterClass(level) { }




Sage::~Sage() { }

